import { MessageType, Mimetype } from '@adiwajshing/baileys'

import { Sticker } from 'wa-sticker-formatter'

import MessageHandler from '../../Handlers/MessageHandler'

import BaseCommand from '../../lib/BaseCommand'

import WAClient from '../../lib/WAClient'

import { IParsedArgs, ISimplifiedMessage } from '../../typings'

export default class Command extends BaseCommand {

    constructor(client: WAClient, handler: MessageHandler) {

        super(client, handler, {

            command: 'steal',

            description: 'Steals stickers',

            category: 'utils',

            usage: `${client.config.prefix}steal [(as caption | tag)[video | image]]`,

            baseXp: 30

        })

    }

    run = async (M: ISimplifiedMessage, parsedArgs: IParsedArgs): Promise<void> => {

        return void M.reply("I still can't steal from cute people")

    }

}
