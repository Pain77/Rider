<div align="center">

  <img src="https://64.media.tumblr.com/76b3cd8202b0aaae57624b569615a86d/tumblr_osbk13DT5t1u8x83lo8_400.gifv" border="0"></a>


<h1 align="center">𝙮𝙖𝙩𝙤𝙧𝙞 : 𝙉𝙚𝙭𝙩 𝙇𝙚𝙫𝙚𝙡 𝙑𝙤𝙞𝙙 𝙒𝙝𝙖𝙩𝙨𝘼𝙥𝙥 𝘽𝙊𝙏𝙏𝙊! <img src="https://c.tenor.com/DX2nbOrRxEUAAAAC/yatori-animes.gif" style="border-radius:5;" width="40px" alt=""><br></h1>
<p align="center">


<div align="left">
  
A Fully Modular and Efficient Bot <br>
  
[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy)



<div align="left">
<br/>

## ✨ Highlights

-   Fully Modular Design
-   Object Oriented
-   Written in [TypeScript](https://www.typescriptlang.org/)
-   Self-Restoring Auth
-   Built with [Baileys](https://github.com/adiwajshing/baileys) (The Best
    WhatsApp Library Out There)
    
## 💪 Contribution

-   Feel free to open issues regarding any problems or if you have any feature
    requests
-   Make sure to follow the ESLint Rules while editing the code and run
    `yarn run prettier-format` before opening PRs

## Follow me on insta.
<p align="left">
  <a href="https://instagram.com/ig_well300"><img src="https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white"/><br>
    
--------

## Give a ⭐ if this project helped you
